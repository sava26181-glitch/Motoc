#!/bin/sh
# Пересобирает app/src/main/assets/index.html из tools/ (если правишь код игры)
cd "$(dirname "$0")"
{ cat tools/head.html; sed '/^if(typeof module/d' tools/engine.js; cat tools/app.js; echo '</script></body></html>'; } > app/src/main/assets/index.html
