// ===ENGINE START===
const DX = 0.5, G = 13;
function rng(seed){let a=seed>>>0;return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
const ss = u => u*u*(3-2*u);

class Terrain {
  constructor(x0){ this.x0 = x0; this.h = [0]; }
  get end(){ return this.x0 + (this.h.length-1)*DX; }
  hAt(x){
    const f=(x-this.x0)/DX, i=Math.floor(f);
    if(i<0) return this.h[0];
    if(i>=this.h.length-1) return this.h[this.h.length-1];
    const t=f-i; return this.h[i]*(1-t)+this.h[i+1]*t;
  }
  seg(L, fn){ const base=this.h[this.h.length-1]; const n=Math.max(1,Math.round(L/DX)); for(let i=1;i<=n;i++) this.h.push(base+fn(i/n)); }
  // closest point to circle center: returns {d, nx, ny}
  probe(x, y, r){
    const h=this.h, x0=this.x0;
    let i0=Math.floor((x-r-x0)/DX)-1, i1=Math.ceil((x+r-x0)/DX)+1;
    if(i0<0) i0=0; if(i1>h.length-2) i1=h.length-2;
    let bd2=1e9, bnx=0, bny=1, below=false, sx=0, sy=1;
    for(let i=i0;i<=i1;i++){
      const ax=x0+i*DX, ay=h[i], ex=DX, ey=h[i+1]-ay;
      let t=((x-ax)*ex+(y-ay)*ey)/(ex*ex+ey*ey); if(t<0)t=0; else if(t>1)t=1;
      const dx=x-(ax+ex*t), dy=y-(ay+ey*t), d2=dx*dx+dy*dy;
      if(d2<bd2){ bd2=d2; bnx=dx; bny=dy; const l=Math.hypot(ex,ey); sx=-ey/l; sy=ex/l; }
    }
    let d=Math.sqrt(bd2);
    if(y < this.hAt(x)){ below=true; }
    if(below || d<1e-6){ return {d: below ? -d : 0, nx:sx, ny:sy}; }
    return {d, nx:bnx/d, ny:bny/d};
  }
}

// ---------- level generators ----------
function genEnduro(len, diff, seed){
  const r=rng(seed), T=new Terrain(-30);
  T.seg(70, u=>0);
  const kinds = diff<0.9 ? ['hill','hill','slope','whoops','table','flat'] :
               diff<1.5 ? ['hill','slope','whoops','table','steps','drop','hill'] :
                          ['hill','slope','whoops','table','steps','drop','drop','table','slope'];
  while(T.end < len){
    const k=kinds[Math.floor(r()*kinds.length)];
    if(k==='flat') T.seg(6+r()*10, u=>0);
    else if(k==='hill'){ const L=18+r()*30, A=(1.2+r()*2.6)*diff, s=r()<0.6?1:-1; T.seg(L,u=>s*A*(1-Math.cos(2*Math.PI*u))/2); }
    else if(k==='slope'){ const L=18+r()*25, D=(r()*2-1)*6*diff; T.seg(L,u=>D*ss(u)); }
    else if(k==='whoops'){ const n=3+Math.floor(r()*4), a=(0.25+r()*0.35)*diff; T.seg(n*2.6,u=>a*Math.pow(Math.sin(Math.PI*u*n),2)); }
    else if(k==='table'){ const h=(1.0+r()*1.4)*diff, Lr=h*3.2; T.seg(Lr,u=>h*Math.pow(u,1.5)); T.seg(3+r()*4,u=>0); T.seg(Lr*1.8,u=>-h*ss(u)); }
    else if(k==='steps'){ const n=2+Math.floor(r()*3); for(let i=0;i<n;i++){ const s=(r()<0.5?1:-1)*(0.25+r()*0.25)*diff; T.seg(1,u=>s*ss(u)); T.seg(1.5+r()*2,u=>0);} }
    else if(k==='drop'){ const h=(1.0+r()*1.2)*diff, Lr=h*3; T.seg(Lr,u=>h*Math.pow(u,1.6)); T.seg(1,u=>-(h+0.6*diff)*u); T.seg(5,u=>0); }
    T.seg(3+r()*5, u=>0);
  }
  const finishX = T.end + 8;
  T.seg(80, u=>0);
  // light smoothing
  for(let p=0;p<1;p++){ const h=T.h, o=h.slice(); for(let i=1;i<h.length-1;i++) h[i]=o[i-1]*0.25+o[i]*0.5+o[i+1]*0.25; }
  const coins=[], cps=[];
  for(let x=40;x<finishX-10;x+=14+r()*14) coins.push({x, y:T.hAt(x)+1.0, got:false});
  for(let x=150;x<finishX-40;x+=150) cps.push({x, y:T.hAt(x)});
  return {T, coins, cps, finishX};
}

function StuntGen(seed){
  const r=rng(seed), T=new Terrain(-30);
  T.seg(60, u=>0);
  const ramps=[];
  function more(){
    const k=r();
    T.seg(10+r()*14, u=>0);
    if(k<0.45){ const h=1.4+r()*1.8, Lr=h*2.8, x=T.end; T.seg(Lr,u=>h*u*u); ramps.push(x); T.seg(1.5,u=>0); T.seg(Lr*3,u=>-h*ss(u)); }
    else if(k<0.8){ const h=3.5+r()*2.5, Lr=h*2.1, x=T.end; T.seg(Lr,u=>h*Math.pow(u,2.2)); ramps.push(x); T.seg(1,u=>0); T.seg(26+h*2,u=>-h*ss(u)); }
    else { const n=3+Math.floor(r()*3), a=0.5+r()*0.4; T.seg(n*4,u=>a*Math.pow(Math.sin(Math.PI*u*n),2)); }
  }
  return { T, ensure(x){ while(T.end < x+120) more(); } };
}

// ---------- bike physics ----------
function makeParams(B, up){
  const e=up.engine||0, w=up.wheels||0, s=up.susp||0, f=up.frame||0;
  const moped = B.type==='moped';
  const r = moped?0.29:0.34, mw=8;
  const M = B.mass*(1-0.04*f) + 65;
  const k = M/150;
  return {
    type:B.type, M, Ic:M*0.33, mw, r, I:0.6*mw*r*r,
    T: 230*B.power*(1+0.13*e), vmax: B.vmax*(1+0.05*e),
    mu: 1.05*B.grip*(1+0.07*w),
    kA: 9500*k*(1+0.10*s), cA: 750*k*(1+0.12*s), kP:45000, cP:600,
    travel: 0.15+0.02*s,
    lean: 420*k*(1+0.06*f), airLean: 700*k*(1+0.10*f), B: 1100*k,
    anch: moped ? [[-0.6,-0.34],[0.62,-0.34]] : [[-0.68,-0.38],[0.70,-0.38]],
    head: moped ? [0.02,0.92] : [0.04,1.02]
  };
}

class Bike {
  constructor(p, x, y){
    this.p=p; this.x=x; this.y=y; this.vx=0; this.vy=0; this.a=0; this.va=0;
    this.wheels = p.anch.map(([lx,ly])=>({x:x+lx, y:y+ly-0.05, vx:0, vy:0, w:0, phi:0, r:p.r, I:p.I, contact:false, cnx:0, cny:1, slip:0}));
    this.pose=0;
  }
  place(x, T){
    const p=this.p;
    const y = Math.max(T.hAt(x+p.anch[0][0]), T.hAt(x+p.anch[1][0])) + p.r - p.anch[0][1] + 0.05;
    this.x=x; this.y=y; this.vx=this.vy=this.va=0; this.a=0;
    this.wheels.forEach((w,i)=>{ w.x=x+p.anch[i][0]; w.y=y+p.anch[i][1]-0.04; w.vx=w.vy=w.w=0; });
  }
  get speed(){ return this.vx*Math.cos(this.a)+this.vy*Math.sin(this.a); }
  step(dt, inp, T){
    this.air = !this.wheels.some(w=>w.contact);
    for(const w of this.wheels){ w.contact=false; w.slip=0; }
    const N=10, h=dt/N;
    for(let s=0;s<N;s++) this.sub(h, inp, T);
    this.pose += ((-inp.leanEff||0) - this.pose)*Math.min(1, dt*8);
  }
  sub(h, inp, T){
    const p=this.p, ca=Math.cos(this.a), sa=Math.sin(this.a);
    let fx=0, fy=-p.M*G, tq=0;
    const air = this.air && !this.wheels[0].contact && !this.wheels[1].contact;
    let lean = inp.lean||0;
    if(air && lean===0){ if(inp.gas) lean=0.55; else if(inp.brake) lean=-0.55; }
    inp.leanEff = lean;
    tq += lean*(air?p.airLean:p.lean);
    tq -= this.va*p.Ic*(air?0.25:0.6);
    const ux=-sa, uy=ca;
    for(let j=0;j<2;j++){
      const w=this.wheels[j], lx=p.anch[j][0], ly=p.anch[j][1];
      const rx=lx*ca-ly*sa, ry=lx*sa+ly*ca;
      const px=this.x+rx, py=this.y+ry, pvx=this.vx-this.va*ry, pvy=this.vy+this.va*rx;
      const dx=w.x-px, dy=w.y-py, dvx=w.vx-pvx, dvy=w.vy-pvy;
      const dA=dx*ux+dy*uy, vA=dvx*ux+dvy*uy;
      const qx=dx-dA*ux, qy=dy-dA*uy, qvx=dvx-vA*ux, qvy=dvy-vA*uy;
      let fA=-p.kA*dA - p.cA*vA;
      if(dA>p.travel) fA -= (dA-p.travel)*p.kA*10 + (vA>0?vA*p.cA*2:0);
      if(dA<-0.12) fA -= (dA+0.12)*p.kA*10;
      const Fx=fA*ux - p.kP*qx - p.cP*qvx, Fy=fA*uy - p.kP*qy - p.cP*qvy;
      w.vx += Fx/p.mw*h; w.vy += (Fy/p.mw - G)*h;
      fx -= Fx; fy -= Fy; tq += rx*(-Fy) - ry*(-Fx);
    }
    this.vx += fx/p.M*h; this.vy += fy/p.M*h; this.va += tq/p.Ic*h;
    if(this.va>9) this.va=9; if(this.va<-9) this.va=-9;
    // drive
    const rw=this.wheels[0];
    if(inp.gas){
      const ratio=Math.max(0, rw.w*rw.r/p.vmax);
      let Tq=p.T*Math.max(0,1-ratio*ratio);
      if(!this.air){ const gs=Math.atan2(T.hAt(this.x+0.7)-T.hAt(this.x-0.7),1.4); const ang=Math.atan2(Math.sin(this.a-gs),Math.cos(this.a-gs)); if(ang>0.3) Tq*=Math.max(0.15,1-(ang-0.3)*2.2); }
      rw.w += Tq/rw.I*h; this.va += 0.4*Tq/p.Ic*h;
    }
    if(inp.brake){
      const fwd=this.speed;
      if(fwd<0.6 && !inp.gas){
        if(rw.w*rw.r > -3){ rw.w -= p.T*0.35/rw.I*h; this.va -= p.T*0.35/p.Ic*h; }
      } else for(let j=0;j<2;j++){ const w=this.wheels[j]; const b=p.B*(j?0.45:1)*h/w.I; if(Math.abs(w.w)<=b) w.w=0; else w.w-=Math.sign(w.w)*b; }
    }
    // integrate
    this.x+=this.vx*h; this.y+=this.vy*h; this.a+=this.va*h;
    for(const w of this.wheels){
      w.w *= (1-0.08*h);
      w.x+=w.vx*h; w.y+=w.vy*h; w.phi-=w.w*h;
      const c=T.probe(w.x,w.y,w.r);
      if(c.d<w.r){
        const pen=w.r-c.d, nx=c.nx, ny=c.ny;
        w.x+=nx*pen; w.y+=ny*pen;
        const vn=w.vx*nx+w.vy*ny; let jn=0;
        if(vn<0){ jn=-vn*p.mw*1.05; w.vx-=vn*nx*1.05; w.vy-=vn*ny*1.05; }
        const tx=ny, ty=-nx, vt=w.vx*tx+w.vy*ty, s=vt-w.w*w.r;
        let jt=-s/(1/p.mw + w.r*w.r/w.I); const lim=p.mu*jn;
        if(jt>lim) jt=lim; else if(jt<-lim) jt=-lim;
        w.vx+=jt/p.mw*tx; w.vy+=jt/p.mw*ty; w.w-=jt*w.r/w.I;
        w.contact=true; w.cnx=nx; w.cny=ny; w.slip=Math.max(w.slip,Math.abs(s));
      }
    }
  }
  headPos(){ const p=this.p, ca=Math.cos(this.a), sa=Math.sin(this.a); const lx=p.head[0]+this.pose*0.15, ly=p.head[1]; return [this.x+lx*ca-ly*sa, this.y+lx*sa+ly*ca]; }
  crashed(T){ const [hx,hy]=this.headPos(); return T.probe(hx,hy,0.17).d < 0.17; }
}
// ===ENGINE END===
if(typeof module!=='undefined') module.exports={Terrain,genEnduro,StuntGen,makeParams,Bike,DX,G};
